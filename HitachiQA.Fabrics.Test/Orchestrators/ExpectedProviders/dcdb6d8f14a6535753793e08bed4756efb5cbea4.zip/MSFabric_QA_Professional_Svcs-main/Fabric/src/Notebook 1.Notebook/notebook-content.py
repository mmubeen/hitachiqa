# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "8d2b7596-ada2-4f36-9159-fcc3a8717530",
# META       "default_lakehouse_name": "Sample_LH1",
# META       "default_lakehouse_workspace_id": "ec54882d-a873-4a37-882d-38c1e7384e38",
# META       "known_lakehouses": [
# META         {
# META           "id": "8d2b7596-ada2-4f36-9159-fcc3a8717530"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd

wrangler_sample_df = pd.read_csv("https://aka.ms/wrangler/titanic.csv")
display(wrangler_sample_df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "editable": true
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
