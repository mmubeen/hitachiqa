from msfabricpysdkcore import FabricClientCore
from models.spark_pool import SparkPools, SparkPool, TFSparkPool, Range, TFSparkPools, AutoScale, ExecutorAllocation
from models.workspace import Workspace


class SparkPoolSvc:
    def __init__(self, fc_client:FabricClientCore):
        self.client = fc_client

    def get_list(self, workspace:Workspace)->SparkPools:
        results = self.client.list_workspace_custom_pools(workspace.id)
        spark_pool_list = SparkPools()
        for p in results:
            if p.name!="Starter Pool":
                pool = SparkPool(id=p.id, name=p.name, type=p.type, nodeSize=p.node_size,
                                 nodeFamily=p.node_family, workspaceId=p.workspace_id)
                pool_autoscale = AutoScale(maxNodeCount=p.auto_scale["maxNodeCount"],
                                           minNodeCount=p.auto_scale["minNodeCount"])
                pool.autoScale = pool_autoscale
                pool_executor_allocation = ExecutorAllocation(maxExecutors=p.dynamic_executor_allocation["maxExecutors"],
                                                              minExecutors=p.dynamic_executor_allocation["minExecutors"])
                pool.dynamic_executor_allocation = pool_executor_allocation
                spark_pool_list.root.append(pool)
        return spark_pool_list

    def get_tf_spark_pools(self, pools:SparkPools):
        tf_pools=TFSparkPools()
        for pool in pools.root:
            item = TFSparkPool(
                id=pool.id,
                name=pool.name,
                node_family=pool.nodeFamily,
                node_size=pool.nodeSize,
                auto_scale=Range(max=pool.autoScale.maxNodeCount,min=pool.autoScale.minNodeCount),
                dynamic_executor_allocation=Range(max=pool.dynamic_executor_allocation.maxExecutors,
                                                  min=pool.dynamic_executor_allocation.minExecutors)
            )
            tf_pools.root.append(item)
        return tf_pools

