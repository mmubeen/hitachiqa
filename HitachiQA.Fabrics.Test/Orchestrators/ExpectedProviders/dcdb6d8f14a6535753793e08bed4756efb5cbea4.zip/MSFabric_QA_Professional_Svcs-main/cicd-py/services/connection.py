import json
from msfabricpysdkcore import FabricClientCore
from services.app_config import AppConfig
from models.connection import Connection, Connections


class ConnectionSvc:
    def __init__(self, fc_client:FabricClientCore):
        self.client = fc_client
        self.app_config = AppConfig()

    def list_connections(self) -> Connections:
        results = self.client.list_connections()
        connection_list = Connections()
        if all(isinstance(connection, Connection) for connection in results):
            connection_list.root = results
        else:
            connection_list.root = [Connection(**connection) for connection in results]
        return connection_list

    def get_cloud_connections(self) -> list[Connection]:
        conns = self.list_connections().root
        return [conn for conn in conns if conn.connectivityType == 'ShareableCloud']

    def get_statedb_connection(self) -> Connection | None:
        conns = self.get_cloud_connections()
        for conn in conns:
            if conn.displayName.find(app_config.environment) != -1 and conn.displayName.find(self.app_config.project) != -1 and conn.displayName.find("StateDB") != -1:
                return conn
        return None

    def get_fabric_connection(self) -> Connection | None:
        conns = self.get_cloud_connections()
        for conn in conns:
            if conn.displayName.find(app_config.environment) != -1 and conn.displayName.find(self.app_config.project) != -1 and conn.displayName.find("Fabric") != -1:
                return conn
        return None

    def get_statedb_connection_by_env(self, env:str) -> Connection | None:
        conns = self.get_cloud_connections()
        for conn in conns:
            if conn.displayName.find(env) != -1 and conn.displayName.find(self.app_config.project) != -1 and conn.displayName.find("StateDB") != -1:
                return conn
        return None

    def get_fabric_connection_by_env(self, env:str) -> Connection | None:
        conns = self.get_cloud_connections()
        for conn in conns:
            if conn.displayName.find(env) != -1 and conn.displayName.find(self.app_config.project) != -1 and conn.displayName.find("Fabric") != -1:
                return conn
        return None

    def get_connection_by_name(self, name:str) -> Connection | None:
        conns = self.get_cloud_connections()
        for conn in conns:
            if conn.displayName == name:
                return conn
        return None

    def get_connection_by_env(self, connection_key, env_key):
        file_path=f"{self.app_config.artifact_directory}/connections.json"
        try:
            with open(file_path, 'r') as file:
                data = json.load(file)
                conn_name = data[connection_key][env_key]
                return self.get_connection_by_name(conn_name)
        except FileNotFoundError:
            return f"Error: File not found at path: {file_path}"
        except json.JSONDecodeError:
            return f"Error: Invalid JSON format in file: {file_path}"

