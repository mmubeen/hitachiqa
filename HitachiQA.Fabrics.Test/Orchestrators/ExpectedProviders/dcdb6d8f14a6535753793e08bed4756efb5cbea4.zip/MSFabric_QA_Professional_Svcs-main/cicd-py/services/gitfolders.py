import os

def find_folders(start_path:str, name_suffix:str)->list[str]:
    """
    Finds folders in a directory tree that have a specific suffix in their names.

    This function traverses the directory tree starting from the given path and
    identifies folders whose names include a specified suffix. The matching folder
    paths are appended to a list and returned as the result. This can be useful for
    filtering directories based on naming conventions or other criteria.

    :param start_path: Path to the base directory from which the traversal starts.
        Defaults to the current directory.
        Type: str
    :param name_suffix: The suffix to be matched in the folder names.
        Type: str
    :return: A list of relative paths to the folders that match the given suffix.
        Type: List[str]
    """
    filtered_folders = []

    # Walk through a directory tree
    for root, dirs, files in os.walk(start_path):
        # Check each directory in the current path
        for dir_name in dirs:
            folder_suffix = f'.{name_suffix}'
            if folder_suffix in dir_name:
                resource_name = dir_name.replace(folder_suffix,'')
                # Create a full path by joining root path with directory name
                filtered_folders.append(resource_name)

    return filtered_folders