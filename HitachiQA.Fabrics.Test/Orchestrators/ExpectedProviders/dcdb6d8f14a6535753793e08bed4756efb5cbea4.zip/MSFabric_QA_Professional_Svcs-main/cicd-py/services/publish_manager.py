import os
from multiprocessing.pool import worker

from msfabricpysdkcore import FabricClientCore

from services.app_config import AppConfig
from services.fabric_publisher import FabricPublisher
from services.fabric_workspace_config import FabricWorkspaceConfig
from services.parameter import ParameterSvc
from services.workspace import WorkspaceSvc


class PublishManager:
    def __init__(self):
        tenant = os.environ.get("FABRIC_TENANT_ID")
        client_id = os.environ.get("FABRIC_CLIENT_ID")
        client_secret = os.environ.get("FABRIC_CLIENT_SECRET")
        self.client = FabricClientCore(tenant_id=tenant, client_id=client_id, client_secret=client_secret)

        token = self.client.get_token()
        if token is None:
            raise Exception("Could not obtain token for FabricClientCore")
        self.app_config = AppConfig()
        tenant=os.environ.get("FABRIC_TENANT_ID")
        client_id = os.environ.get("FABRIC_CLIENT_ID")
        client_secret = os.environ.get("FABRIC_CLIENT_SECRET")
        self.client = FabricClientCore(tenant_id=tenant, client_id=client_id, client_secret=client_secret)

    def execute(self):
        publisher = FabricPublisher(FabricWorkspaceConfig().to_fabric_workspace())
        publisher.publish_all()
