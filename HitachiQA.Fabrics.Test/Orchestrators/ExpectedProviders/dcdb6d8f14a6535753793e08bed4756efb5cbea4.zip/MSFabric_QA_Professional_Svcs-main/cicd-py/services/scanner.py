from msfabricpysdkcore import FabricClientCore
from models.tf_fabric import TFFabric
from services.app_config import AppConfig
from services.lakehouse import LakehouseSvc
from services.parameter import ParameterSvc
from services.fabric_env import FabricEnvironmentService
from services.spark_pool import SparkPoolSvc
from services.workspace import WorkspaceSvc
import os

class Scanner:
    def __init__(self):
        tenant = os.environ.get("FABRIC_TENANT_ID")
        client_id = os.environ.get("FABRIC_CLIENT_ID")
        client_secret = os.environ.get("FABRIC_CLIENT_SECRET")
        self.client = FabricClientCore(tenant_id=tenant, client_id=client_id, client_secret=client_secret)

        token = self.client.get_token()
        if token is None:
            raise Exception("Could not obtain token for FabricClientCore")
        self.app_config = AppConfig()
        
        
    def scan_workspace(self):
        print("Scanning workspaces...")
        workspace_svc = WorkspaceSvc(self.client)
        print("Scanning workspaces pools...")
        pools_svc = SparkPoolSvc(self.client)
        pools = pools_svc.get_list(workspace_svc.get_source_workspace())
        print("Scanning workspaces environments...")
        envs_svc = FabricEnvironmentService(self.client)
        envs = envs_svc.get_list(workspace_svc.get_source_workspace())
        print("Scanning workspaces lakehouses...")
        lkh_svc = LakehouseSvc(self.client)
        lkhs = lkh_svc.get_list(workspace_svc.get_source_workspace())
        print("Collect parameters...")
        param_svc = ParameterSvc(self.client)

        return TFFabric(spark_pools=pools_svc.get_tf_spark_pools(pools).root,
                       spark_envs=envs_svc.get_tf_spark_envs(envs).root,
                       workspaces=workspace_svc.get_tf_workspaces(),
                       lake_houses=lkh_svc.get_tf_lake_houses(lkhs).root,
                       fb_parameters=param_svc.get_list().root)
        
    def create_report(self):
        tf_fabric_workspace = self.scan_workspace()
        print("Write json output...")
        with open(f"{self.app_config.artifact_directory}/tf_fabric.json", "w") as f:
            f.write(tf_fabric_workspace.model_dump_json())