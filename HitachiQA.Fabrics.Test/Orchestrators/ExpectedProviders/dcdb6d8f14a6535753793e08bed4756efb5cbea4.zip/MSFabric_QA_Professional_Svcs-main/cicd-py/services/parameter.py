import shutil

from msfabricpysdkcore import FabricClientCore

from models.parameter import Parameters, Parameter
from services.app_config import AppConfig
from services.connection import ConnectionSvc
import json
import yaml

class ParameterSvc:
    def __init__(self, fc_client:FabricClientCore):
        self.client = fc_client
        self.app_config = AppConfig()

    def get_list(self):
        params = Parameters()
        connection_svc=ConnectionSvc(self.client)

        for conn_type in ["state_db", "fabric"]:
            source_id = target_id = None
            name = conn_type
            for env in ["DEV", self.app_config.environment]:
                conn = connection_svc.get_connection_by_env(conn_type,env)
                match env:
                    case "DEV":
                        source_id = conn.id if conn else "None"
                    case _:
                        target_id = conn.id if conn else "None"
            params.root.append(Parameter(name= name, source_id=source_id, target_id=target_id))
        return params

    def create_fabric_yaml(self):
        root_path = self.app_config.artifact_directory
        src_path = self.app_config.repository_directory
        # Load parameters.json
        with open(f"{root_path}/parameters.json", "r") as f:
            data = json.load(f)

        find_replace = []
        spark_pool = []

        # Parse id_map for find_replace
        for entry in data:
            if "id_map" in entry:
                for mapping in entry["id_map"]:
                    find_replace.append({
                        "find_value": mapping["source"],
                        "replace_value": {
                            "QA": mapping["target"]
                        }
                    })
            if "pool_map" in entry:
                for mapping in entry["pool_map"]:
                    spark_pool.append({
                        "instance_pool_id": mapping["pool_id"],
                        "replace_value": {
                            "QA": {
                                "type": "Workspace",
                                "name": mapping["pool_name"]
                            }
                        },
                        "item_name": [mapping["env"]]
                    })

        output = {}
        if find_replace:
            output["find_replace"] = find_replace
        if spark_pool:
            output["spark_pool"] = spark_pool


        with open(f"{root_path}/parameter.yml", "w") as f:
            yaml.dump(output, f, sort_keys=False, default_flow_style=False)
        shutil.copy(f"{root_path}/parameter.yml", f"{src_path}/parameter.yml")
        with open(f"{src_path}/parameter.yml", "r") as f:
            print(f.read())