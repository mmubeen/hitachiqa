from msfabricpysdkcore import FabricClientCore

from models.fabric_env import FabricEnvs, FabricEnv, TFFabricEnvs, TFFabricEnv
from models.spark_pool import ExecutorAllocation

from models.workspace import Workspace





class FabricEnvironmentService:
    def __init__(self, fc_client:FabricClientCore):
        self.client = fc_client

    def get_env_settings(self, workspace:Workspace, env:FabricEnv):
        results = self.client.list_environments(workspace.id, env.id)
        return results[0].settings.get(
            "fabric.environment.settings"
        )

    def get_list(self, workspace:Workspace)->FabricEnvs:
        results = self.client.list_environments(workspace.id, False)
        fabric_env_list = FabricEnvs()

        for e in results:
            settings = self.client.get_published_settings(workspace.id, e.id)
            env = FabricEnv(id=e.id, display_name=e.display_name, type=e.type, workspace_id=e.workspace_id)
            env.instance_pool_name = settings["instancePool"]["name"]
            env.instance_pool_id = settings["instancePool"]["id"]
            env.driverCores = settings["driverCores"]
            env.driverMemory = settings["driverMemory"]
            env.executorCores = settings["executorCores"]
            env.executorMemory = settings["executorMemory"]
            env.dynamicExecutorAllocation = ExecutorAllocation(maxExecutors=settings["dynamicExecutorAllocation"]["maxExecutors"],
                                                          minExecutors=settings["dynamicExecutorAllocation"]["minExecutors"])
            fabric_env_list.root.append(env)
        return fabric_env_list

    def get_tf_spark_envs(self, envs:FabricEnvs):
        tf_envs=TFFabricEnvs()
        for env in envs.root:
            item = TFFabricEnv(
                id=env.id,
                name=env.display_name,
                workspace_id = env.workspace_id,
                instance_pool_name= env.instance_pool_name,
                instance_pool_id= env.instance_pool_id,
                driverCores= env.driverCores,
                driverMemory= env.driverMemory,
                executorCores= env.executorCores,
                executorMemory= env.executorMemory,
                dynamicExecutorAllocation= env.dynamicExecutorAllocation
            )
            tf_envs.root.append(item)
        return tf_envs