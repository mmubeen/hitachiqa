import os

class AppConfig:
    def __init__(self):
        self.workspace_id = os.environ.get("WORKSPACE_ID")
        self.workspace_name = os.environ.get("WORKSPACE_NAME")
        self.repository_directory = os.environ.get("REPOSITORY_DIRECTORY")
        self.environment = os.environ.get("ENVIRONMENT", "QA")
        self.tenant_id=os.environ.get("FABRIC_TENANT_ID")
        self.client_id = os.environ.get("FABRIC_CLIENT_ID")
        self.client_secret = os.environ.get("FABRIC_CLIENT_SECRET")
        self.project=os.environ.get("PROJECT")
        self.item_type_in_scope = ["Lakehouse", "Notebook", "DataPipeline", "Environment"]
        self.artifact_directory = os.environ.get("ARTIFACT_DIRECTORY")

    def validate(self):
        if not self.workspace_id:
            raise Exception("WORKSPACE_ID is required")
        if not self.workspace_name:
            raise Exception("WORKSPACE_NAME is required")
        if not self.repository_directory:
            raise Exception("REPOSITORY_DIRECTORY is required")
        if not self.artifact_directory:
            raise Exception("ARTIFACT_DIRECTORY is required")
        if not self.environment:
            raise Exception("ENVIRONMENT is required")
        if not self.tenant_id:
            raise Exception("FABRIC_TENANT_ID is required")