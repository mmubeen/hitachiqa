from msfabricpysdkcore import FabricClientCore

from services.app_config import AppConfig
from models.lakehouse import LakeHouses, Lakehouse, TFLakeHouses, TFLakehouse
from models.workspace import Workspace
from services.gitfolders import find_folders


class LakehouseSvc:
    def __init__(self, fc_client:FabricClientCore):
        self.client = fc_client

    def get_list(self, workspace:Workspace)->LakeHouses:
        app_config = AppConfig()
        lakehouse_folders = find_folders(app_config.repository_directory, "Lakehouse")
        results=self.client.list_lakehouses(workspace.id)
        lakehouse_list = LakeHouses()
        for folder in lakehouse_folders:
            for item in results:
                if folder == item.display_name:
                    lk = Lakehouse(id=item.id, display_name=item.display_name, type=item.type, workspace_id=item.workspace_id)
                    if "defaultSchema" in item.properties:
                        lk.schema_enabled = True
                    lakehouse_list.root.append(lk)
        return lakehouse_list

    def get_tf_lake_houses(self, lake_houses:LakeHouses):
        tf_envs=TFLakeHouses()
        for lake_houses in lake_houses.root:
            item = TFLakehouse(
                id=lake_houses.id,
                name=lake_houses.display_name,
                schema_enabled=lake_houses.schema_enabled
            )
            tf_envs.root.append(item)
        return tf_envs