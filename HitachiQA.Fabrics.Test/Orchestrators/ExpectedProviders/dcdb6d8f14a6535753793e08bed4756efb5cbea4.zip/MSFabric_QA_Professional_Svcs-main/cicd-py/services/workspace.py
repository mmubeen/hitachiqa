from msfabricpysdkcore import FabricClientCore

from services.app_config import AppConfig
from models.workspace import Workspace, Workspaces, TFWorkspace, TFWorkspaces


class WorkspaceSvc:
    def __init__(self, fc_client: FabricClientCore):
        self.client = fc_client

    def list_workspaces(self) -> Workspaces:
        results = self.client.list_workspaces()
        workspace_list = Workspaces()
        # Check if results are already Workspace objects
        if all(isinstance(workspace, Workspace) for workspace in results):
            workspace_list.root = results
        else:
            # Only apply the transformation if results are dictionaries
            workspace_list.root = [Workspace(**workspace.__dict__) for workspace in results]

        return workspace_list

    def get_target_workspace(self) -> Workspace | None:
        app_config = AppConfig()
        for workspace in self.list_workspaces().root:
            if workspace.display_name.find(app_config.workspace_name) != -1:
                return workspace
        return None

    def get_source_workspace(self) -> Workspace | None:
        app_config = AppConfig()
        for workspace in self.list_workspaces().root:
            if workspace.display_name.find("DEV") != -1 and workspace.display_name.find(app_config.project) != -1:
                return workspace
        return None

    def get_tf_workspaces(self):
        source_workspace = self.get_source_workspace()
        target_workspace = self.get_target_workspace()
        source_tf_workspace = TFWorkspace(id=source_workspace.id, name=source_workspace.display_name)
        target_tf_workspace = TFWorkspace(id=target_workspace.id, name=target_workspace.display_name)
        tf_workspaces = TFWorkspaces(source=source_tf_workspace, target=target_tf_workspace)
        return tf_workspaces
