from fabric_cicd import FabricWorkspace
from services.app_config import AppConfig
import logging
import sys
# Set the logging level for the Azure Identity library
logger = logging.getLogger("azure.identity")
logger.setLevel(logging.DEBUG)

# Direct logging output to stdout. Without adding a handler,
# no logging output is visible.
handler = logging.StreamHandler(stream=sys.stdout)
logger.addHandler(handler)

class FabricWorkspaceConfig:
    def __init__(self):
        app_config = AppConfig()
        self.workspace_id = app_config.workspace_id
        self.repository_directory = app_config.repository_directory
        self.item_type_in_scope = app_config.item_type_in_scope
        self.environment = app_config.environment
        tenant=app_config.tenant_id
        client_id = app_config.client_id
        client_secret = app_config.client_secret

    def to_fabric_workspace(self):
        return FabricWorkspace(
            workspace_id=self.workspace_id,
            repository_directory=self.repository_directory,
            item_type_in_scope=self.item_type_in_scope,
            environment=self.environment
        )