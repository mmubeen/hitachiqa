from typing import Optional, List

from msfabricpysdkcore.spark_custom_pool import SparkCustomPool
from pydantic import BaseModel, RootModel


class AutoScale(BaseModel):
    enabled: bool = True
    minNodeCount: int = 0
    maxNodeCount: int = 0

class ExecutorAllocation(BaseModel):
    enabled: bool = True
    minExecutors: int = 0
    maxExecutors: int = 0

class Range(BaseModel):
    min: Optional[int]
    max: Optional[int]

class SparkPool(BaseModel):
    id: Optional[str]
    name: Optional[str]
    nodeFamily: Optional[str]
    nodeSize: Optional[str]
    workspaceId: Optional[str]
    type: Optional[str]
    autoScale: AutoScale = AutoScale()
    dynamic_executor_allocation: ExecutorAllocation = ExecutorAllocation()

class SparkPools(RootModel):
    root: Optional[List[SparkPool]] = []

class TFSparkPool(BaseModel):
    id: Optional[str]
    name: Optional[str]
    node_family: Optional[str]
    node_size: Optional[str]
    auto_scale: Range
    dynamic_executor_allocation: Range

class TFSparkPools(RootModel):
    root: Optional[List[TFSparkPool]] = []

#*******
# {
#     "spark_pools": [
#         {
#             "name": "Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "Large",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 19
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 17
#             }
#         },
#         {
#             "name": "X-Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "XLarge",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 48
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 47
#             }
#         },
#         {
#             "name": "XX-Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "XXLarge",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 24
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 23
#             }
#         }
#     ]
# }
#*************/