from typing import List

from pydantic import BaseModel, RootModel


class Parameter(BaseModel):
    name: str
    target_id: str
    source_id: str

class Parameters(RootModel):
     root: List[Parameter] = []

