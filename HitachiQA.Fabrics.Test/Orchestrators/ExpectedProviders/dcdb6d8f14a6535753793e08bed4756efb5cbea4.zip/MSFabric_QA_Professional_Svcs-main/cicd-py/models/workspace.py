from pydantic import BaseModel, RootModel
from typing import List, Optional


class Workspace(BaseModel):
    id:  str | None = None
    display_name:  str | None = None
    description:  str | None = None
    type:  str | None = None
    capacity_id:  str | None = None

class TFWorkspace(BaseModel):
    id:  str | None = None
    name:  str | None = None

class TFWorkspaces(BaseModel):
    source: TFWorkspace
    target: TFWorkspace

class Workspaces(RootModel):
    root: Optional[List[Workspace]] = []