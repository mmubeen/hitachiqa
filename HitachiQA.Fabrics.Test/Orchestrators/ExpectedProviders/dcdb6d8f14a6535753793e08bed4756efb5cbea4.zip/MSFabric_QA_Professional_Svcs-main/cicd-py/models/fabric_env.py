from pydantic import RootModel, BaseModel
from typing import List, Optional

from models.spark_pool import ExecutorAllocation


class FabricEnv(BaseModel):
    id: str = ""
    display_name: str = ""
    type: str = ""
    workspace_id: str = ""
    instance_pool_name: str = ""
    instance_pool_id: str = ""
    driverCores: int = 0
    driverMemory: str = ""
    executorCores: int = 0
    executorMemory: str = ""
    dynamicExecutorAllocation: ExecutorAllocation = ExecutorAllocation()

class FabricEnvs(RootModel):
    root: List[FabricEnv] = []

class TFFabricEnv(BaseModel):
    id: Optional[str]
    name: Optional[str]
    workspace_id: str = ""
    instance_pool_name: str = ""
    instance_pool_id: str = ""
    driverCores: int = 0
    driverMemory: str = ""
    executorCores: int = 0
    executorMemory: str = ""
    dynamicExecutorAllocation: ExecutorAllocation

class TFFabricEnvs(RootModel):
    root: Optional[List[TFFabricEnv]] = []