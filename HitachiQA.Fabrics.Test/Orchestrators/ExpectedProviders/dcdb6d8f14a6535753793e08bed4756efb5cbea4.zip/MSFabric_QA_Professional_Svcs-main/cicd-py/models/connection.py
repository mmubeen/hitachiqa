from pydantic import BaseModel, RootModel
from typing import List, Optional


class Connection(BaseModel):
    id:  str | None = None
    displayName:  str | None = None
    gatewayId:  str | None = None
    type:  str | None = None
    connectivityType:  str | None = None


class Connections(RootModel):
    root: Optional[List[Connection]] = []