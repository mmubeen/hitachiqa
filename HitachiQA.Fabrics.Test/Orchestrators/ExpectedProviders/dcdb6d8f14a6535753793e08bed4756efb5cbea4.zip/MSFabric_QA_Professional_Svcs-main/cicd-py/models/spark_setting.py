from typing import Optional, List

from pydantic import BaseModel, RootModel


class SparkSetting(BaseModel):
    id: Optional[str]
    name: Optional[str]

class SparkSettings(RootModel):
    root: Optional[List[SparkSetting]] = []

class TFSparkSetting(BaseModel):
    id: Optional[str]
    name: Optional[str]

class TFSparkPools(RootModel):
    root: Optional[List[TFSparkSetting]] = []

#*******
# {
#     "spark_pools": [
#         {
#             "name": "Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "Large",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 19
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 17
#             }
#         },
#         {
#             "name": "X-Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "XLarge",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 48
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 47
#             }
#         },
#         {
#             "name": "XX-Large Pool",
#             "node_family": "MemoryOptimized",
#             "node_size": "XXLarge",
#             "auto_scale": {
#                 "min": 1,
#                 "max": 24
#             },
#             "dynamic_executor_allocation": {
#                 "min": 1,
#                 "max": 23
#             }
#         }
#     ]
# }
#*************/
