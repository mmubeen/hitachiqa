from pydantic import RootModel, BaseModel
from typing import List, Optional


class Lakehouse(BaseModel):
    id: str = ""
    display_name: str = ""
    type: str = ""
    workspace_id: str = ""
    schema_enabled: bool = False

class LakeHouses(RootModel):
    root: List[Lakehouse] = []

class TFLakehouse(BaseModel):
    id: Optional[str]
    name: Optional[str]
    schema_enabled: Optional[bool] = False

class TFLakeHouses(RootModel):
    root: Optional[List[TFLakehouse]] = []