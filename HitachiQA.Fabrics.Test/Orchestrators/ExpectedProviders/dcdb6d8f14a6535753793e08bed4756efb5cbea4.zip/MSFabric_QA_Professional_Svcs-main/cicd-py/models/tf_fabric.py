from pydantic import BaseModel

from models.lakehouse import TFLakeHouses
from models.parameter import Parameters
from models.fabric_env import TFFabricEnvs
from models.spark_pool import TFSparkPools
from models.workspace import TFWorkspaces


class TFFabric(BaseModel):
    spark_pools: TFSparkPools
    spark_envs: TFFabricEnvs
    workspaces: TFWorkspaces
    lake_houses: TFLakeHouses
    fb_parameters: Parameters