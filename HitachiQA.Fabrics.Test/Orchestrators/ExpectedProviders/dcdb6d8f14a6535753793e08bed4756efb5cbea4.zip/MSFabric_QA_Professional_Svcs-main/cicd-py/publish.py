from dotenv import find_dotenv, load_dotenv
import logging

from services.publish_manager import PublishManager

logging.basicConfig(level=logging.DEBUG)

def main():
    print("Starting the publisher...")
    load_dotenv(find_dotenv())
    PublishManager().execute()
    print("Ending the publisher...")

if __name__ == "__main__":
    main()