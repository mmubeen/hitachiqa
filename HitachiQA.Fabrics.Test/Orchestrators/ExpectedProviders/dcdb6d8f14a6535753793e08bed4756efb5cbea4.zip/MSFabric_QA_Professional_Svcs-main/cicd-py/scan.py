from dotenv import find_dotenv, load_dotenv
from services.scanner import Scanner
import logging


logging.basicConfig(level=logging.DEBUG)


def main():
    print("Starting the scanner...")
    load_dotenv(find_dotenv())
    Scanner().create_report()
    print("Ending the scanner...")

if __name__ == "__main__":
    main()