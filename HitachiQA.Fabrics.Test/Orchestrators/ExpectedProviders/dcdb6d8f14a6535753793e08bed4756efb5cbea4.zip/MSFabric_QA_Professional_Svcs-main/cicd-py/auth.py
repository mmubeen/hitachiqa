import msal

class FabricAuthenticator:
    def __init__(self, tenant_id, client_id, client_secret, scope):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.scope = scope
        self.authority = f"https://login.microsoftonline.com/{self.tenant_id}"
        self.app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=self.authority,
            client_credential=self.client_secret
        )

    def get_token(self):
        """
        Acquire a Microsoft Fabric (Azure) access token using client credentials.
        """
        result = self.app.acquire_token_for_client(scopes=[self.scope])
        if "access_token" in result:
            return result["access_token"]
        else:
            raise Exception(f"Could not obtain token: {result.get('error_description', result)}")