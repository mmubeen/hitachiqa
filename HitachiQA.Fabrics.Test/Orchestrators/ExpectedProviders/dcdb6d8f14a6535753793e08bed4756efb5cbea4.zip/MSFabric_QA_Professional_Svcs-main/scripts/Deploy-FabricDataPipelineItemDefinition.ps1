﻿param (
    [Parameter(Mandatory=$true)]
    [string] $fabricToken,
    [Parameter(Mandatory=$true)]
    [string] $workspaceId = "" ,
    [Parameter(Mandatory=$true)]
    [string] $sourceCodePath,
    [Parameter(Mandatory=$true)]
    [string] $pipelineMappingFileName = "_FabricDataPipelineParameterMapping.json",
    [ValidateSet("Development", "dev", "qa", "prod")]
    [string] $targetEnv = "qa"
)

##################################
# Define Authorization Header
##################################

$AuthHeader = @{
    'Authorization' = "Bearer $fabricToken"
    'Content-Type' = "application/json"
}

##################################
# Load Pipeline Configuration
##################################

$pipelineIdPath = Join-Path -Path $sourceCodePath -ChildPath $pipelineMappingFileName
$platformResults = Get-Content -Path $pipelineIdPath -Raw | ConvertFrom-Json

##################################
# Deploy Data Pipelines
##################################

foreach ($pipeline in $platformResults) {
    Start-Sleep -Seconds 1
    Write-Output "..Start Deployment of Data Pipeline: $($pipeline.displayName)"

    $filePath = "$($pipeline.folderPath)\pipeline-content-$($targetEnv).json"
    $filePath

    # Check if the file exists
    if (-Not (Test-Path -Path $filePath)) {
        Write-Host "`tFile not found: $filePath"
        continue
    }

    # Read and encode file content
    $fileContent = Get-Content -Path $filePath -Raw
    $fileBytes = [System.Text.Encoding]::UTF8.GetBytes($fileContent)
    $contentPayload = [Convert]::ToBase64String($fileBytes)

    $ItemDefinitionPart = @{
        "path" = "pipeline-content.json"
        "payload" = $contentPayload
        "payloadType" = "InlineBase64"
    }

    $ItemBody = @{
        "displayName" = $pipeline.displayName
        "description" = $pipeline.description
        "definition" = @{ "parts" = @($ItemDefinitionPart) }
    } | ConvertTo-Json -Compress -Depth 100

    #$ItemBody = $ItemBody | ConvertTo-Json -Compress -Depth 100
    $UpdateDefinitionUrl = "https://api.fabric.microsoft.com/v1/workspaces/$($workspaceId)/dataPipelines/$($pipeline.pipelineId)/updateDefinition"

    try {
        $response = Invoke-WebRequest -Uri $UpdateDefinitionUrl -Headers $AuthHeader -Body $ItemBody -Method POST

        # Output the status code and status description
        Write-Output "`tStatus Code: $($response.StatusCode)"
        Write-Output "`tStatus Description: $($response.StatusDescription)"

    } catch {
        # Output the error message
        Write-Output "`tError Message: $($_.Exception.Message)"

        # Output the detailed error information
        if ($_.Exception.Response) {
            $errorResponse = $_.Exception.Response
            Write-Output "`n`tEXCEPTION FOR: $($pipeline.displayName) `n`t`tReview to make sure Service Account user has access to any connections used in $($pipeline.displayName)."
            Write-Output "`tStatus Code: $($errorResponse.StatusCode)"
            Write-Output "`tStatus Description: $($errorResponse.StatusDescription)"
        }
    }
}


##################################
# Delete Data Pipelines not in Source
##################################
$DeleteDataPipelineList = @()

$pipelineUrl = "https://api.fabric.microsoft.com/v1/workspaces/{0}/dataPipelines" -f $workspaceId

$response = (Invoke-RestMethod -Uri $pipelineUrl -Headers $AuthHeader -Method 'Get')
$deployedDataPipelines = $response.value

## If 
foreach ($pipeline in $response.value ) {
    # Check if the displayName from the REST API call is not in the JSON content
    if (-not ($platformResults | Where-Object { $_.displayName -eq $pipeline.displayName })) {
        # Add the pipeline ID to the delete list
        $DeleteDataPipelineList += $pipeline.id
    }
}

$maxAttempts = 4
$attempts = 0
$previousCount = $DeleteDataPipelineList.Count

while ($DeleteDataPipelineList.Count -gt 0 -and $attempts -lt $maxAttempts) {
    $currentCount = $DeleteDataPipelineList.Count
    foreach ($pipelineId in $DeleteDataPipelineList) {
        $pipelineDeleteUrl = $pipelineUrl + "/" + $pipelineId
        try {
            $responseGet = Invoke-RestMethod -Uri $pipelineDeleteUrl -Headers $AuthHeader -Method 'Get'
            Write-Output "`tDeleting Data Pipeline not in Source Code: $pipelineId | $($responseGet.displayName)" 

            if ($responseGet.Length -gt 0) {
                Invoke-RestMethod -Uri $pipelineDeleteUrl -Headers $AuthHeader -Method 'Delete'
                $DeleteDataPipelineList = $DeleteDataPipelineList | Where-Object { $_ -ne $pipelineId }
            }             
            
        } catch {
            # If the delete fails, move to the next item in the list
            $message = "Failed to delete pipeline with ID $pipelineId : $_"
            Write-Error $message
            continue
        }
    }
    
    # Check if the list count has changed
    if ($DeleteDataPipelineList.Count -eq $currentCount) {
        $attempts++
    } else {
        $attempts = 0
        $previousCount = $DeleteDataPipelineList.Count
    }
}