﻿##################################
# Script to Swap Out Basic Parameters for Deploying Data Fabric Pipelines
##################################
# Objective:
# This script is designed to swap out basic parameters for deploying Data Fabric Pipelines to upper environments.
# It updates JSON files with new values based on the provided parameters.
#
# Parameters:
# - $stateDbName: The name of the state database. Default is "statedb".
# - $stateDbConnectionId: The connection ID for the state database. This parameter is mandatory.
# - $workspaceId: The ID of the workspace. This parameter is mandatory.
# - $workspaceConnectionId: The connection ID for the workspace. This parameter is mandatory.
# - $targetEnv: The target environment for deployment. Valid values are "Development", "dev", "qa", "prod". Default is "qa". This parameter is mandatory.
# - $pipelineMappingFileName: The name of the pipeline mapping file. Default is "FabricDataPipelineMapping.json". This parameter is mandatory.
##################################

param (
    [string] $stateDbName = "statedb",
    [Parameter(Mandatory=$true)]
    [string] $stateDbConnectionId,
    [Parameter(Mandatory=$true)]
    [string] $workspaceId,
    [Parameter(Mandatory=$true)]
    [string] $workspaceConnectionId,
    [Parameter(Mandatory=$true)]
    [ValidateSet("Development", "dev", "qa", "prod")]
    [string] $targetEnv = "qa",
    [Parameter(Mandatory=$true)]
    [string] $sourceCodePath,
    [Parameter(Mandatory=$true)]
    [string] $pipelineMappingFileName = "_FabricDataPipelineParameterMapping.json"
)

##################################
# Function to return a JSON value for a given path.
##################################
function Get-PropertyValue {
    param (
        [Parameter(Mandatory=$true)]
        [psobject]$JsonObject,
        [Parameter(Mandatory=$true)]
        [string]$JsonPath
    )

    $pathParts = $JsonPath -split '\.'
    $currentObject = $JsonObject

    foreach ($part in $pathParts) {
        if ($part -match '\[(\d+)\]$') {
            $index = [int]$matches[1]
            $property = $part -replace '\[\d+\]$'
            if ($currentObject.$property -and $currentObject.$property.Count -gt $index) {
                $currentObject = $currentObject.$property[$index]
            } else {
                return $null
            }
        } else {
            if ($currentObject.$part) {
                $currentObject = $currentObject.$part
            } else {
                return $null
            }
        }
    }

    return $currentObject
}

##################################
# Function to Traverse and Update JSON Paths
##################################
function Get-JsonPaths {
    param (
        [Parameter(Mandatory = $true)]
        [string]$JsonFilePath,
        [string]$stateDbConnectionId,
        [string]$workspaceId,
        [string]$workspaceConnectionId,
        [string]$PipelineDispalyName,
        [array]$lakehouseArray,
        [string]$OutputFilePath
    )

    # Load JSON content from the specified file
    $json = Get-Content -Path $JsonFilePath -Raw | ConvertFrom-Json

    ##################################
    # Recursive Function to Traverse JSON Structure
    ##################################
    function Traverse-Json {
        param (
            [Parameter(Mandatory = $true)]
            [object]$Node,
            [string]$Path = ''
        )

        if ( $Node -eq $null ) {
            return
        }

        if ($Node -is [PSObject]) {
            foreach ($property in $Node.PSObject.Properties) {
                $newPath = if ($Path) { "$Path.$($property.Name)" } else { $property.Name }
                if ($property.Value -ne $null) {
                    Traverse-Json -Node $property.Value -Path $newPath
                }
            }
        } elseif ($Node -is [System.Collections.IList]) {
            if ($Node.Count -eq 0) {
                return
            }
            for ($i = 0; $i -lt $Node.Count; $i++) {
                $newPath = "$Path[$i]"
                if ($Node[$i] -ne $null) {
                    Traverse-Json -Node $Node[$i] -Path $newPath
                }
            }
        } else {
            $keyJSONPath = $Path
            $keyName = $Path.Substring($Path.LastIndexOf('.') + 1)
            $keyValue = $Node
           
            switch ($keyName) {
                "workspaceId" {
                    $originalWorkspaceId = $Node
                    Write-Output "`tJSON Changed Path: $keyJSONPath"
                    Write-Output "`t`tOriginal Value: $originalWorkspaceId" 
                    Write-Output "`t`tNew Value: $workspaceId"
                    Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $workspaceId
                }
                "database" {
                    if ($keyValue -eq "sqldb01-westus-sql01-dev-g11") {
                        Write-Output "`tJSON Changed Path: $keyJSONPath"
                        Write-Output "`t`tOriginal Value: $keyValue" 
                        Write-Output "`t`tNew Value: $stateDbName"
                        Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $stateDbName
                    }
                }
                "connection" {
                    if ($keyValue -eq "b844064f-a585-4be0-b6d8-b9170ae7de09") {
                        Write-Output "`tJSON Changed Path: $keyJSONPath"
                        Write-Output "`t`tOriginal Value: $keyValue" 
                        Write-Output "`t`tNew Value: $stateDbConnectionId"
                        Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $stateDbConnectionId
                    }
                    if ($keyValue -eq "58c99a5d-7612-4873-9481-31c4f8ac2a55") {
                        Write-Output "`tJSON Changed Path: $keyJSONPath"
                        Write-Output "`t`tOriginal Value: $keyValue" 
                        Write-Output "`t`tNew Value: $workspaceConnectionId"
                        Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $workspaceConnectionId
                    }
                }
                "type" {
                    if ($keyValue -eq "InvokePipeline") {
                        $operationTypePath = $Path.Substring(0, $Path.LastIndexOf('.'))
                        $operationType = Get-Item -Path $operationTypePath
                        Write-Output "`tJSON Path:operationType $($oprationType.operationType)"
                        if ($operationType.PSObject.Properties["externalReferences"]){
                            Write-Output "`tJSON Path:externalReferences $($operationType.PSObject.Properties["externalReferences"])"
                            if($operationType.externalReferences.PSObject.Properties["connection"]) {
                                Write-Output "`tJSON Path:externalReferences.connection $($operationType.externalReferences.PSObject.Properties["connection"])"
                            }
                        }
                        
                       
                        if ($oprationType.operationType -eq "Invok:eFabricPipeline" -and $operationType.PSObject.Properties["externalReferences"] -and $operationType.externalReferences.PSObject.Properties["connection"]) {
                            $originalConnection = $operationType.externalReferences.connection
                            Write-Output "`tJSON Changed Path: $($operationTypePath.externalReferences.connection)"
                            Write-Output "`t`tOriginal Value: $originalConnection" 
                            Write-Output "`t`tNew Value: $workspaceConnectionId"
                            Update-JsonValue -JsonObject $json -JsonPathToUpdate "$operationTypePath.externalReferences.connection" -NewValue $workspaceConnectionId
                        }
                    }
                }
                "pipelineId" {
                    $lkupPipelineId = ($fabricDataPipelineMapping | Where-Object { $_.logicalId -eq $keyValue }).pipelineId
                    $originalPipelineId = $keyValue
                    $newPipelineId = $lkupPipelineId
                    if([string]::IsNullOrEmpty($newPipelineId)){
                       Write-Output "`t`tmissing new Value->Original Value: $originalPipelineId" 
                    }
                    else{
                        Write-Output "`tJSON Changed Path: $keyJSONPath"
                        Write-Output "`t`tOriginal Value: $originalPipelineId" 
                        Write-Output "`t`tNew Value: $newPipelineId"
                        Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $newPipelineId
                    }
                }
                
                "artifactId" {
                    $linkedServiceTypePath = $keyJSONPath -replace "typeProperties.artifactId", "type"
                    $linkedServiceType = Get-PropertyValue -JsonObject $json -JsonPath $linkedServiceTypePath
                    $linkedServiceNamePath = $keyJSONPath -replace "properties.typeProperties.artifactId", "name"
                    $linkedServiceName = Get-PropertyValue -JsonObject $json -JsonPath $linkedServiceNamePath
                    if ($linkedServiceType -eq "Lakehouse" -and $linkedServiceName) {
                        $lkupLakehouseId = ($lakehouseArray | Where-Object { $_.displayName -eq $linkedServiceName }).id
                    } else {
                        $lkupLakehouseId = ($lakehouseArray | Where-Object { $_.logicalId -eq $keyValue }).id
                    }
                    $newLakehouseId = if ($lkupLakehouseId -eq $null) { $keyValue } else { $lkupLakehouseId }

                    Write-Output "`tJSON Changed Path: $keyJSONPath"
                    Write-Output "`t`tOriginal Value: $keyValue" 
                    Write-Output "`t`tNew Value: $newLakehouseId"
                    Update-JsonValue -JsonObject $json -JsonPathToUpdate $keyJSONPath -NewValue $newLakehouseId
                }
            } 
        }
    }

    ##################################
    # Function to Update JSON Values
    ##################################
    function Update-JsonValue {
        param (
            [Parameter(Mandatory = $true)]
            [object]$JsonObject,
            [Parameter(Mandatory = $true)]
            [string]$JsonPathToUpdate,
            [Parameter(Mandatory = $true)]
            [string]$NewValue
        )

        $pathElements = $JsonPathToUpdate -split '\.'
        $parentObject = $JsonObject

        for ($i = 0; $i -lt $pathElements.Length - 1; $i++) {
            $element = $pathElements[$i]
            if ($element -match '\[(\d+)\]$') {
                $index = [int]$matches[1]
                $element = $element.Substring(0, $element.Length - $matches[0].Length)
                $parentObject = $parentObject.$element[$index]
            } else {
                $parentObject = $parentObject.$element
            }
        }

        $lastElement = $pathElements[-1]
        if ($lastElement -match '\[(\d+)\]$') {
            $index = [int]$matches[1]
            $lastElement = $lastElement.Substring(0, $lastElement.Length - $matches[0].Length)
            $parentObject.$lastElement[$index] = $NewValue
        } else {
            $parentObject.$lastElement = $NewValue
        }

        $validateResult = if ($parentObject.$lastElement -eq $NewValue) { $true } else { $false }
        # Write-Output "......Pipeline: $PipelineDispalyName, Path: $JsonPathToUpdate, New Value: $NewValue, Validation: $validateResult`n"
        Write-Output "`t`tParameter Swap Validation Check: $validateResult`n"
    }

    # Traverse the JSON structure
    Traverse-Json -Node $json

    # Define output path and save the updated JSON    
    $json | ConvertTo-Json -Compress -Depth 100 | %{
            [Regex]::Replace($_, 
              "\\u(?<Value>[a-zA-Z0-9]{4})", {
                    param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                        [System.Globalization.NumberStyles]::HexNumber))).ToString() } )} | Set-Content "$($OutputFilePath)\pipeline-content-$($targetEnv).json" -Force
}


#$global:target_env = $targetEnv

# Combine the path and file name to get the full file path
$pipelineIdPath = Join-Path -Path $sourceCodePath -ChildPath $pipelineMappingFileName
$fabricDataPipelineMapping = Get-Content -Path $pipelineIdPath -Raw | ConvertFrom-Json

#$sourceCodePath
$fabricDataPipelineMapping | ForEach-Object { 
    Write-Output "***************************************************"
    Write-Output "* Start parameter swapping for: $($_.displayName)"
    Write-Output "***************************************************"
    $pipelineSourcePath = "$($_.folderPath)\pipeline-content.json"
    Get-JsonPaths -JsonFilePath $pipelineSourcePath -stateDbConnectionId $stateDbConnectionId -workspaceId $workspaceId -workspaceConnectionId $workspaceConnectionId -PipelineDispalyName $_.displayName -lakehouseArray $_.lakehouses  -OutputFilePath $_.folderPath
  }
