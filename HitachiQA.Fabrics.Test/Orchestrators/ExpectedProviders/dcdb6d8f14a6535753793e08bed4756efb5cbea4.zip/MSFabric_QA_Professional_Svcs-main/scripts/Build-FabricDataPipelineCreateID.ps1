﻿param (
    [string] $fabricToken,
    [string] $workspaceId,
    [string] $sourceCodePath
)

$parameterFileName = "_FabricDataPipelineParameterMapping.json"


# Function to read .platform files and extract specified values
function Read-PlatformFiles {
    param (
        [string]$BaseFolderPath
    )

    $results = @()

    # Get all subfolders in the base folder
    $folders = Get-ChildItem -Path $BaseFolderPath -Directory
    $counter = 1

    foreach ($folder in $folders) {
        $platformFilePath = Join-Path -Path $folder.FullName -ChildPath ".platform"

        if (Test-Path -Path $platformFilePath) {
            $platformContent = Get-Content -Path $platformFilePath -Raw | ConvertFrom-Json

            if ($platformContent.metadata.type -eq "DataPipeline") {
                $contentFilePath = Join-Path -Path $folder.FullName -ChildPath "pipeline-content.json"
            } else {
                $contentFilePath = $null
            }

            $result = [pscustomobject]@{
                logicalId = $platformContent.config.logicalId
                type = $platformContent.metadata.type
                displayName = $platformContent.metadata.displayName
                description = $platformContent.metadata.description
                folderPath = $folder.FullName
                contentFile = $contentFilePath
                pipelineId = $null
                
            }

            $results += $result

        }
    }

    return $results
}



$auth_header = @{
    #'Content-Type' = "application/json"
    'Authorization' = "Bearer {0}" -f $fabricToken
}

        
$pipelines_url =  "https://api.fabric.microsoft.com/v1/workspaces/{0}/dataPipelines" -f $workspaceId
$pipelines_response = (Invoke-RestMethod -Uri $pipelines_url -Headers $auth_header -Method GET).value

# Get list of Lakehouses for a Workspaces
$listLakehouse_url = "https://api.fabric.microsoft.com/v1/workspaces/{0}/lakehouses" -f $workspaceId
$lakehouse_response = (Invoke-RestMethod -Uri $listLakehouse_url -Headers $auth_header -Method GET).value

## List of Lakehouses for a Workspace, this will be used with Pipeline data for reference during deployment.
$lakehouse_list = @()

$lakehouse_platform = Read-PlatformFiles -BaseFolderPath "$($sourceCodePath)\Lakehouse"


foreach ($lakehouse in $lakehouse_response) {
    $lakehouseName = $lakehouse.displayName 
    $lakehousePlatform = $lakehouse_platform | Where-Object { $_.displayName -eq $lakehouseName }

    $lakehouse_list += @{
        "displayName" = $lakehouse.displayName 
        "id" = $lakehouse.id
        "logicalId" = $lakehousePlatform.logicalId
    }
}


$dataPipelineSourcePath = "$($sourceCodePath)\DataPipeline"
$platformResults = Read-PlatformFiles -BaseFolderPath $dataPipelineSourcePath

$joinedPlatformLookup = @()
# Join the objects based on displayName
foreach ($platformObj in $platformResults) {
    $body = [pscustomobject]@{}
    $post_auth_header = @{}
    $lkupPipelines = $pipelines_response | Where-Object { $_.displayName -eq $platformObj.displayName }

    $response = ""
    $operation_url = ""
    if ($lkupPipelines.id -eq $null) {
        $bodyDescription = if ($platformObj.description -eq $null) { "" } else { $platformObj.description }

        $post_auth_header = @{
            'Content-Type' = "application/json"
            'Authorization' = "Bearer $fabricToken"
        }

        $body = [pscustomobject]@{
            displayName = $platformObj.displayName
            description = $bodyDescription
        } | ConvertTo-Json

        $createEmptyDPUrl = "https://api.fabric.microsoft.com/v1/workspaces/{0}/dataPipelines" -f $workspaceId ##qa
        $response = Invoke-WebRequest -Uri $createEmptyDPUrl -Headers $post_auth_header -Body $body -Method POST

        $response.StatusCode
        $response.StatusDescription
        $operation_url = $response.Headers["Location"]

        while ($response.StatusCode -eq 202) {
            Start-Sleep -Seconds 2  # Wait for the specified retry interval
            $response = Invoke-WebRequest -Uri $operation_url -Headers $auth_header -Method GET
        }

        if ($response.StatusCode -eq 201) {
            $responseJson = $response.Content | ConvertFrom-Json
            $pipelineId = $responseJson.id
        }
    
    } else { 
        $pipelineId = $lkupPipelines.id 
    }

    $joinedPlatformLookup += [PSCustomObject]@{
            logicalId = $platformObj.logicalId
            type = $platformObj.type
            displayName = $platformObj.displayName
            description = $platformObj.description
            folderPath = $platformObj.folderPath
            #contentFile = $platformObj.contentFile
            pipelineId = $pipelineId
            lakehouses = $lakehouse_list
        }
    
}

# Output the joined objects
$jsonfile = $joinedPlatformLookup | ConvertTo-Json -Depth 3
$jsonfile | Set-Content -Path "$($sourceCodePath)\$($parameterFileName )"
Write-Output "Pipeline parameter file written to $($sourceCodePath)\$($parameterFileName )"
