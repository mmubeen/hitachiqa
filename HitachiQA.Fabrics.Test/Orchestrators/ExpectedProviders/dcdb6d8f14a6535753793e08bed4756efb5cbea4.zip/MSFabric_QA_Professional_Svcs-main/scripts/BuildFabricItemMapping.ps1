param (
    [string] $FabricAuthScope = "api://sp-datafabric-infra-dev-g11-user-auth",
    [string] $FabricToken,
    [string] $DevWorkspaceId = "b34dcd5b-e793-463f-84eb-ecac53773607", #used to get lookup values from DEV Workspace that are not included in the logicalId
    [Parameter(Mandatory=$true)]
    [string] $SourceCodePath

)

# Define the module name used in script.
$moduleName = "powershell-yaml"

# Check if the module is installed
$moduleInstalled = Get-Module -ListAvailable -Name $moduleName

if ($moduleInstalled) {
    Write-Output "Module $moduleName is already installed. Importing..."
    
    # Import the module
    Import-Module -Name $moduleName
} else {
    Write-Output "Module $moduleName is not installed. Installing..."
    
    # Install the module
    Install-Module -Name $moduleName -Force -Scope CurrentUser
    
    # Import the module
    Import-Module -Name $moduleName
}

# Verify the module is imported
if (Get-Command -Name ConvertFrom-Yaml -ErrorAction SilentlyContinue) {
    Write-Output "Module $moduleName imported successfully."
} else {
    Write-Output "Failed to import module $moduleName."
}

$fabricItemFileName = "_FabricItemMapping.json"
# $SourceCodePath  = "$($SourceCodePath)"
function Read-PlatformFiles {
    param (
        [string]$BaseFolderPath
    )

    $results = @()

    # Get all subfolders in the base folder
    $folders = Get-ChildItem -Path $BaseFolderPath -Directory #-Filter "*.Environment"
    foreach ($folder in $folders) {
        $platformFilePath = Join-Path -Path $folder.FullName -ChildPath ".platform"

        if (Test-Path -Path $platformFilePath) {
            $platformContent = Get-Content -Path $platformFilePath -Raw | ConvertFrom-Json

            switch ($platformContent.metadata.type) {
                "DataPipeline" {
                    $contentFileName = "pipeline-content.json"
                    $contentFilePath = Join-Path -Path $folder.FullName -ChildPath  $contentFileName
                }
                "Environment" {
                    $contentFileName = "Setting/Sparkcompute.yml"
                    $contentFilePath = Join-Path -Path $folder.FullName -ChildPath  $contentFileName
                    $environmentSparkPoolId = (Get-Content -Path $contentFilePath -Raw | ConvertFrom-Yaml).instance_pool_id
                    $environmentSparkPoolName = ($global:devLkupSparkPools | Where-Object { $_.id -eq $environmentSparkPoolId }).name
                }
                "Lakehouse" {
                    $contentFileName = "lakehouse.metadata.json"
                    $contentFilePath = Join-Path -Path $folder.FullName -ChildPath  $contentFileName
                }
                "Notebook" {
                    $contentFileName = "notebook-content.py"
                    $contentFilePath = Join-Path -Path $folder.FullName -ChildPath $contentFileName
                    
                }
                default {
                    $contentFileName = $null
                    $contentFilePath = $null
                    $environmentSparkPoolName = $null
                    $environmentSparkPoolId = $null
                }
            }

            $result = [pscustomobject]@{
                logicalId                = $platformContent.config.logicalId
                type                     = $platformContent.metadata.type
                displayName              = $platformContent.metadata.displayName
                description              = $platformContent.metadata.description
                folderPath               = $folder.FullName
                contentFile              = if (Test-Path -Path $contentFilePath) { $contentFilePath } else { $null }
                environmentLibrariesPath = if (Test-Path -Path (Join-Path -Path $folder.FullName -ChildPath "Libraries")) { Join-Path -Path $folder.FullName -ChildPath "Libraries" } else { $null }
                environmentDevSparkPoolId = if ($platformContent.metadata.type -eq "Environment") { $environmentSparkPoolId } else { $null } 
                environmentSparkPoolName = if ($platformContent.metadata.type -eq "Environment") { $environmentSparkPoolName } else { $null } 
            }

            $results += $result

        }
    }

    return $results
}

function Get-DevSparkPools {
    param (
        [string]$DevWorkspaceId
    )

    $sparkPoolsUrl = "https://api.fabric.microsoft.com/v1/workspaces/{0}/spark/pools" -f $DevWorkspaceId
    $allResults = @()

    try {
        do {
            $responseSparkPools = Invoke-RestMethod -Uri $sparkPoolsUrl -Headers $global:auth_header -Method GET
            $allResults += $responseSparkPools.value
            $sparkPoolsUrl = $responseSparkPools.continuationUri
        } while ($sparkPoolsUrl)

        return $allResults
    } catch {
        $errorMessage = "Error Code: $($_.Exception.Response.StatusCode) - $($_.Exception.Message)"
        throw $errorMessage
    }
}

$global:auth_header = @{
   'Content-Type' = "application/json"
   'Authorization' = "Bearer {0}" -f $fabricToken
 }

$global:devLkupSparkPools = Get-DevSparkPools -DevWorkspaceId $DevWorkspaceId

$allPlatformFiles = Read-PlatformFiles -BaseFolderPath $SourceCodePath
# Output the joined objects
$jsonfile = $allPlatformFiles | ConvertTo-Json -Depth 100
$jsonfile | Set-Content -Path "$($SourceCodePath)\$($fabricItemFileName)"
# $jsonfile | Set-Content -Path "C:\Users\chq-bradl\Desktop\PowerShellScripts\$($fabricItemFileName)"

Write-Output "Fabric Item mapping file for Terraform written to $($SourceCodePath)\$($fabricItemFileName )"