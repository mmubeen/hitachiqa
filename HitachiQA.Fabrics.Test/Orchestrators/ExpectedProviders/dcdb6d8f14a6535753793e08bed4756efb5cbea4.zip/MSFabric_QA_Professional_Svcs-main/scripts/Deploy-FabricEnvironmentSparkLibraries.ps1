##################################
# Deploy Fabric Environment Spark Libraries
##################################
# Objective:
# The purpose of this script is to get all of the Fabric Environment Spark Libraries 
# from Fabric source code and deploy it to the workspace environment. This is not 
# supported by Terraform and should happen after the Environments have been created 
# for a workspace.
# 
# This supports .whl and .yml files for the custom libraries.
#
# Parameters:
# - $FabricToken: The authentication token for accessing Fabric.
# - $WorkspaceId: The ID of the workspace where the environments are located.
# - $SourceCodePath: The path to the Fabric source code (default: "../../../src/fabric").
# - $FabricItemType: The type of Fabric item to process (default: "Environment").
# - $WaitForPublish: Boolean flag to wait for the publish process to complete (default: $false).
##################################

param (
    [Parameter(Mandatory = $true)]
    [string] $FabricToken,
    [Parameter(Mandatory = $true)]
    [string] $WorkspaceId, 
    [string] $SourceCodePath,
    [string] $FabricItemType = "Environment",
    [bool] $WaitForPublish = $false
)

# Check if the module is installed
if (-not (Get-Module -ListAvailable -Name powershell-yaml)) {
    # Install the module if it's not installed
    Install-Module -Name powershell-yaml -Force -Scope CurrentUser
}

# Import the module
Import-Module -Name powershell-yaml


##################################
# Function to Gather Source Content Information from Microsoft Fabric Environments
##################################
function Read-PlatformFiles {
    param (
        [string]$BaseFolderPath,
        [string]$FabricItemType = "Environment"
    )

    $results = @()

    # Get all subfolders in the base folder
    $folders = Get-ChildItem -Path $BaseFolderPath -Directory -Filter "*.$($FabricItemType)"

    foreach ($folder in $folders) {
        $platformFilePath = Join-Path -Path $folder.FullName -ChildPath ".platform"
        if (Test-Path -Path $platformFilePath) {
            $platformContent = Get-Content -Path $platformFilePath -Raw | ConvertFrom-Json
            $whlFiles = @()
            $customLibraryFiles = @()

            $result = [pscustomobject]@{
                logicalId   = $platformContent.config.logicalId
                type        = $platformContent.metadata.type
                displayName = $platformContent.metadata.displayName
                description = $platformContent.metadata.description
                folderPath  = $folder.FullName
            }
            $contentFileName = "Setting/Sparkcompute.yml"
            $contentFilePath = Join-Path -Path $folder.FullName -ChildPath  $contentFileName
            $environmentSparkPoolId = (Get-Content -Path $contentFilePath -Raw | ConvertFrom-Yaml).instance_pool_id
            $environmentSparkPoolName = ($global:devLkupSparkPools | Where-Object { $_.id -eq $environmentSparkPoolId }).name
            $platformFilePath = Join-Path -Path $folder.FullName -ChildPath ".platform"
            $libraryFilePath = Join-Path -Path $folder.FullName -ChildPath "Libraries"

            # Conditionally add the attribute
            if (Test-Path -Path $contentFilePath) { $result | Add-Member -MemberType NoteProperty -Name "contentFile" -Value $contentFilePath }
            if (Test-Path -Path (Join-Path -Path $folder.FullName -ChildPath "Libraries")) { $result | Add-Member -MemberType NoteProperty -Name "environmentLibrariesPath" -Value $libraryFilePath }
            if ($platformContent.metadata.type -eq "Environment") {
                $result | Add-Member -MemberType NoteProperty -Name "environmentDevSparkPoolId" -Value $environmentSparkPoolId
                $result | Add-Member -MemberType NoteProperty -Name "environmentSparkPoolName" -Value $environmentSparkPoolName
            }
            
            # Get all files in the library file path and its subfolders, currently supports .whl and .yml files
            if (Test-Path -Path $libraryFilePath) {
                $files = Get-ChildItem -Path $libraryFilePath -Recurse -File
                
                foreach ($file in $files) {
                    if ($file.Extension -eq ".whl") {
                        $whlFiles += $file.FullName
                    }
                    elseif ($file.Extension -eq ".yml") {
                        $customLibraryFiles += $file.FullName
                    }
                }
                if ($whlFiles | Where-Object { $_ }) { $result | Add-Member -MemberType NoteProperty -Name "whlFiles" -Value $whlFiles }
                if ($customLibraryFiles | Where-Object { $_ }) { $result | Add-Member -MemberType NoteProperty -Name "customLibraryFiles" -Value $customLibraryFiles }
            }
            $results += $result
        }
    }

    return $results
}

##################################
# Gets list of environments for a workspace from Microsoft Fabric.
##################################
function Get-Environments {
    param (
        [string] $WorkspaceId
    )

    $environmentsUrl = "https://api.fabric.microsoft.com/v1/workspaces/$($WorkspaceId)/environments"
    $environmentsUrl
    try {
        $environments = Invoke-RestMethod -Uri $environmentsUrl -Method Get -Headers $global:auth_header
        $environments.StatusDescription
        $environments.StatusCode

        return $environments
    }
    catch {
        Write-Error "Failed to retrieve environments: $_"
        return $null
    }
}

##################################
# Function to Retrieve Environment Library State from Microsoft Fabric. 
# This will check the status of the libraries in the environment.
##################################
function Get-EnvironmentLibraryState {
    param (
        [string]$WorkspaceId,
        [string]$environmentId
    )

    $librariesUrl = "https://api.fabric.microsoft.com/v1/workspaces/$($WorkspaceId)/environments/$($environmentId)"

    try {
        Write-Host "Retrieving Spark Environment status for environment: $environmentId"
        $libraries = Invoke-RestMethod -Uri $librariesUrl -Method Get -Headers $global:auth_header
        Write-Host "`tState: $($libraries.properties.publishDetails.state)"
        return @{ 
            id          = $libraries.id
            type        = $libraries.type
            displayName = $libraries.displayName
            state       = $libraries.properties.publishDetails.state
        }
    }
    catch {
        Write-Error "Failed to retrieve libraries for environment: $environmentId. Error: $($_.Exception.Message)"
        return $null
    }
}

##################################
# Function to Upload Staging Libraries to Microsoft Fabric Environment
##################################
function Send-StagingLibraries {
    param (
        [string]$FabricToken,
        [string]$WorkspaceId,
        [string]$environmentId,
        [string]$libraryType,
        [array]$libraryPaths
    )

    $librariesUrl = "https://api.fabric.microsoft.com/v1/workspaces/$WorkspaceId/environments/$environmentId/staging/libraries"
    $headers = @{
        "Content-Type"  = "multipart/form-data"
        "Authorization" = "Bearer $FabricToken"
    }
    $uploadStageStatus = @()
    Write-Host "URL Load Files: $librariesUrl"
    foreach ($library in $libraryPaths) {

        # $fileContent = Get-Content -Path $library -Raw -Encoding Byte
        # $fileContent = [System.IO.File]::ReadAllBytes($library)
        # $fileName = [System.IO.Path]::GetFileName($filePath)
        # $base64Content = [Convert]::ToBase64String($fileContent)

        # $boundary = [System.Guid]::NewGuid().ToString()
        $form = @{
            "file" = Get-Item -Path $library
        }
        Start-Sleep -Seconds 3
        Write-Host "`tStarting upload of $libraryType library: $library"
        
        try {
            $response = Invoke-WebRequest -Uri $librariesUrl -Method Post -Headers $headers -Form $form
            # $response = Invoke-RestMethod -Uri $librariesUrl -Method Post -Headers $headers -Body $libraryBody -ContentType "multipart/form-data; boundary=$boundary" #-UseBasicParsing
            # Invoke-WebRequest -Uri $librariesUrl -Method Post -Headers $global:library_auth_headers -Form $form
            $uploadStageStatus += @{
                WorkspaceId   = $WorkspaceId
                environmentId = $environmentId
                library       = $library
                statusCode    = "Success $($response.StatusCode)"
                statusMessage = "Success: Upload successfull" #$($response.StatusDescription)"
            }
        }
        catch {
            Write-Error "Failed to upload $libraryType library: $_"
            $uploadStageStatus += @{
                WorkspaceId   = $WorkspaceId
                environmentId = $environmentId
                library       = $library
                statusCode    = $_.FullyQualifiedErrorId
                statusMessage = "Failed: $($_.ErrorDetails.Message)"
            }
        }
    }
    return $uploadStageStatus
}

##################################
# Function to Publish Staging Libraries to Microsoft Fabric Environment
##################################
function Publish-StagingLibraries {
    param (
        [string]$WorkspaceId,
        [string]$environmentId
    )

    $publishUrl = "https://api.fabric.microsoft.com/v1/workspaces/$($WorkspaceId)/environments/$($environmentId)/staging/publish"

    try {
        Write-Host "`tPublishing staging libraries for environment: $environmentId"
        $response = Invoke-WebRequest -Uri $publishUrl -Method Post -Headers $global:auth_header
        Write-Host "`tPublish response: $($response.StatusDescription)"
        # Write-Host "Staging libraries request successfully sent for environment: $environmentId"
        return $response.Content
    }
    catch {
        Write-Error "Failed to publish libraries for environment: $environmentId. Error: $($_.Exception.Message)"
        return $null
    }
}

# Set auth headers for both the POST and GET. "Content-Type"  = "multipart/form-data" is needed for the POST of Libraries.
$global:auth_header = @{
    'Content-Type'  = "application/json"
    'Authorization' = "Bearer {0}" -f $FabricToken
}

# Gets all of the platform files for Environment, this will get any .whl files to be deployed
$itemPlatformFiles = Read-PlatformFiles -BaseFolderPath $SourceCodePath -FabricItemType $FabricItemType

# Get the environments for the workspace
$workspaceEnvironments = Get-Environments -WorkspaceId $WorkspaceId #- WorkspaceId $WorkspaceId

foreach ($environment in $workspaceEnvironments.value) {
    $environmentId = $environment.id
    $environmentItem = $itemPlatformFiles | Where-Object { $_.displayName -eq $environment.displayName }
    $environmentItem
    $whlFiles = $environmentItem.whlFiles
    #$customLibraryFiles = $environmentItem.customLibraryFiles

    $getState = Get-EnvironmentLibraryState -WorkspaceId $WorkspaceId -environmentId $environmentId

    if ($getState.state -eq "Running") {
        Write-Output "`tEnvironment libraries are currently being published. Skipping upload and publish."
        continue
        # May need to add this back in if needing to wait for running Environments. [BL][20250130]
        # Wait-ForEnvironmentState -WorkspaceId $WorkspaceId -environmentId $environmentId
    }

    Write-Host $environment

    if ($whlFiles) {
        # Send the whl libraries to the environment for staging.
        "-------------------------------------"
        $uploadStatus = Send-StagingLibraries -FabricToken $FabricToken -WorkspaceId $WorkspaceId -environmentId $environmentId -libraryType "wheelFiles" -libraryPaths $whlFiles

        $uploadStatus | ForEach-Object {
            Write-Output "`tLibrary: $($_.library), Status: $($_.statusMessage)"
        }  
    }
    # if ($customLibraryFiles) {
    #     # Send the custom yml libraries to the environment for staging.
    #     $uploadStatus = Send-StagingLibraries -WorkspaceId $WorkspaceId -environmentId $environmentId -libraryType "customYmlFiles" -libraryPaths $customLibraryFiles
    #     $uploadStatus | ForEach-Object {
    #         Write-Output "`tLibrary: $($_.library), Status: $($_.statusMessage)"
    #     } 
    # }
    # if (-Not $whlFiles -and -Not $customLibraryFiles) {
    if (-Not $whlFiles) {
        Write-Output "`tNo libraries to upload for environment: $($environment.displayName)"
        continue
    }

    if ($WaitForPublish) {
        Write-Output "`tPublishing libraries to staging environment..."
        Publish-StagingLibraries -WorkspaceId $WorkspaceId -environmentId $environmentId
        $finalState = Wait-ForEnvironmentState -WorkspaceId $WorkspaceId -environmentId $environmentId
        Write-Host "`tFinal State: $($finalState.state)"
    }
    else {
        Publish-StagingLibraries -WorkspaceId $WorkspaceId -environmentId $environmentId
    }
}