##################################
# Convert Fabric Python Source to Jupyter Notebook
##################################
# This script converts a Fabric Python source file into a Jupyter Notebook file prior to Terraform deployment.
# Parameters are swapped out so Terraform tokens can be used during the Terraform deployment.
# 
# Parameters:
# - $keyVaultName: The name of the Key Vault to be used.
# - $source_code_path: The path to the source code directory containing the Fabric Python files.
##################################

param (
    [string] $keyVaultName,
    [string] $sourceCodePath 
)

##################################
# Find all Notebook folders
##################################
$notebookFolders = Get-ChildItem -Path $sourceCodePath -Filter "*.Notebook" -Recurse

foreach ($folder in $notebookFolders) {
    $pyPath = Join-Path $folder.FullName "notebook-content.py"
    $ipynbPath = Join-Path $folder.FullName "notebook-content.ipynb"
   
    if (Test-Path $pyPath) {
        ##################################
        # Read content from the Python file
        ##################################
        $content = Get-Content $pyPath -Raw
       
        ##################################
        # Remove META lines and replace keyvault name
        ##################################
        $content = $content -replace "#\s*Fabric\s*notebook\s*source\s*#\s*METADATA\s*\*{20}", "# NOTEBOOK_METADATA ********************" `
                            -replace "# PARAMETERS CELL \*{20}", "# PARAMETERS_CELL ********************" `
                            -replace "# METADATA \*{20}", "* CELL_METADATA ********************" `
                            -replace "# META", "" |
                            ForEach-Object { $_ -replace "kv-wu2-datafab-dv-g11", $keyVaultName } 

        # Initialize cells arrays
        $cells = @()
        # Initialize Notebook metadata
        $nbMetadata = @{}
       
        ##################################
        # Split content by sections
        ##################################
        $sections = $content.Trim() -split '(?=# \w+ \*{20})'
       
        foreach ($section in $sections) {
            $section = $section.Trim()
            if ([string]::IsNullOrWhiteSpace($section)) { continue }
           
            ##################################
            # Get Cell type
            ##################################
            $type = if ($section -match "# (\w+) \*{20}") { 
                        $matches[1]  # Extract the matched word
                    } else { "UNKNOWN" } # Default type if no match is found

            switch ($type) {
                "NOTEBOOK_METADATA" {
                    ##################################
                    # Process NOTEBOOK_METADATA section
                    ##################################
                    $notebookMetadata = $section -replace "# NOTEBOOK_METADATA \*{20}", "" 
                    $notebookMetadata = $notebookMetadata.Trim() | ConvertFrom-Json

                    # Check if dependencies and environment arrays exist
                    if ($notebookMetadata.dependencies -and $notebookMetadata.dependencies[0].environment) {
                        # Switch environment Ids in Metadata to Terraform Tokens
                        switch ($notebookMetadata.dependencies[0].lakehouse.default_lakehouse_name.ToUpper()) {
                            "LAKEHOUSE_BRONZE" { $notebookMetadata.dependencies[0].environment[0].environmentId = "{{ .ENVIRONMENT_BRONZE_ID }}" }
                            "LAKEHOUSE_SILVER" { $notebookMetadata.dependencies[0].environment[0].environmentId = "{{ .ENVIRONMENT_SILVER_ID }}" }
                            default { $notebookMetadata.dependencies[0].environment[0].environmentId = "{{ .ENVIRONMENT_BRONZE_ID }}" }
                        }

                        $notebookMetadata.dependencies[0].environment[0].workspaceId = "{{ .WORKSPACE_ID }}"
                    }

                    # Check if lakehouse array exists
                    if ($notebookMetadata.dependencies[0].lakehouse) {
                        $notebookMetadata.dependencies[0].lakehouse.default_lakehouse_workspace_id = "{{ .WORKSPACE_ID }}"
                        $notebookMetadata.dependencies[0].lakehouse.default_lakehouse = "{{ .$($notebookMetadata.dependencies[0].lakehouse.default_lakehouse_name.ToUpper())_ID }}"
                    }
                    if ($notebookMetadata.dependencies[0].lakehouse.known_lakehouses) {
                        $notebookMetadata.dependencies[0].lakehouse.known_lakehouses = @([PSCustomObject]@{ id = "{{ .LAKEHOUSE_BRONZE_ID }}" },[PSCustomObject]@{ id = "{{ .LAKEHOUSE_SILVER_ID }}" })
                    }

                    $nbMetadata = $notebookMetadata
                }
                "PARAMETERS_CELL" {
                    ##################################
                    # Process PARAMETERS_CELL section
                    ##################################
                    $nbCode, $cellMetadata = $section -split "\* CELL_METADATA \*{20}"
                    $nbCode = $nbCode -replace "# \w+ \*{20}", "" -replace "# CELL", "" 
                    $cellMetadata = $cellMetadata.Trim() | ConvertFrom-Json
                    $cells += @{
                        cell_type = "code"
                        source = @($nbCode.Trim())
                        metadata = @{microsoft = $cellMetadata; tags = @("parameters")}
                    }
                }
                "MARKDOWN" {
                    ##################################
                    # Process MARKDOWN section
                    ##################################
                    $section = $section.Trim() -replace "# \w+ \*{20}", ""
                    $section = $section -split "`n" | ForEach-Object { $_ -replace "^# ", "" }
                    $section = $section -join "`n"
                    $cells += @{
                        cell_type = "markdown"
                        source = @($section.Trim())
                        metadata = @{
                                language = "python"
                                language_group = "synapse_pyspark"
                        }
                    }
                }
                default {
                    ##################################
                    # Process default code cell section
                    ##################################
                    $nbCode, $cellMetadata = $section -split "\* CELL_METADATA \*{20}"
                    $nbCode = $nbCode -replace "# CELL \*{20}", "" -replace "# CELL", "" -replace "\* CELL_METADATA \*{20}", ""
                    $cellMetadata = $cellMetadata.Trim() | ConvertFrom-Json
                    $cells += @{
                        cell_type = "code"
                        source = @($nbCode.Trim())
                        metadata = $cellMetadata
                        outputs = @()
                        execution_count = $null
                    }
                }
            }
        }

        ##################################
        # Create JSON content for the Jupyter Notebook
        ##################################
        $ipynbContent = @{
            cells = $cells
            metadata = $nbMetadata
            nbformat = 4
            nbformat_minor = 2
        }
       
        $jsonContent = $ipynbContent| ConvertTo-Json -Depth 100 | %{
            [Regex]::Replace($_, 
              "\\u(?<Value>[a-zA-Z0-9]{4})", {
                    param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                        [System.Globalization.NumberStyles]::HexNumber))).ToString() } )} 
        [System.IO.File]::WriteAllText($ipynbPath, $jsonContent, [System.Text.Encoding]::UTF8)
        Write-Host "Converted $pyPath ----> $ipynbPath"
    }
    else {
        Write-Warning "Python file not found in $($folder.FullName)"
    }
}